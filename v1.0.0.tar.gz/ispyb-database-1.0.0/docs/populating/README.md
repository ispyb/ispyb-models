# Table Population

Some information on how to populate the relevant tables